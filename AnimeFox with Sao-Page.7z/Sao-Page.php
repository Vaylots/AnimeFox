<!DOCTYPE html>

<html>


<head>
 <script type="text/javascript"  src="js/jquery-3.5.1.js" ></script>
 <script type="text/javascript" src="js/jquery-ui.js"></script>
 <script type="text/javascript" src="js/scriptSao.js"></script>
 <script type="text/javascript" src="js/bootstrap.js"></script>
 <link rel="stylesheet" type="text/css" href="css/StyleAnime-Page.css">
 <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
 <link rel="shortcut icon" href="images/Logo/icon.png" type="image/png">
 <meta charset="UTF-8">
 <title>AnimeFox</title>
</head>


<body>
  <header>
    <div>
     <a href="index.php"> <img class="col-lg-1 col-sm-" id=Logo src="images/Logo/Logo.png"></a>
   </div>
 </header>


 <div class='row'>
  <div class='col-lg-12'>
    <?
    include "Content-Sao.php"
    ?>

  </div>
</div>

</div>


</div>


</body>



</html>
