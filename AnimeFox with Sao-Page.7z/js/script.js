$(document).ready(function() { 
$('#SideBar').hide();
  $('#SideBarAlert').hover(function() {
  $("#SideBar").toggle("slide",200);
  });



$('#SAO').hide();
  



$('#VE').hide();
  $('#butnv').click(function() {
  $("#VE").slideToggle(500);
  });



$('#akame').hide();
  $('#butna').click(function() {
  $("#akame").slideToggle(500);
  });



$('#jojo').hide();
  $('#butnj').click(function() {
  $("#jojo").slideToggle(500);
  });




$('.Drama').hide();
  $('#Drama').click(function() {
  $(".Drama").slideToggle(200);
  });


 
$('.Action').hide();
  $('#Action').click(function() {
  $(".Action").slideToggle(200);
  });



$('.Fantasy').hide();
  $('#Fantasy').click(function() {
  $(".Fantasy").slideToggle(200);
  });



$('.Daily').hide();
  $('#Daily').click(function() {
  $(".Daily").slideToggle(200);
  });

});

$('#butnjC').show();
  $('#butnj').click(function() {
    $("#butnjC").slideToggle(300);
  });